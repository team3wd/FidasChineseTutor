(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/lib/pending.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Pending vocab queue (localStorage key: ch_pending) — AI-parsed words awaiting user approval before entering the study bank
__turbopack_context__.s([
    "clearPendingLesson",
    ()=>clearPendingLesson,
    "loadPending",
    ()=>loadPending,
    "savePending",
    ()=>savePending,
    "totalPendingCount",
    ()=>totalPendingCount
]);
const STORAGE_KEY = 'ch_pending';
function loadPending() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    } catch  {
        return {};
    }
}
function savePending(store) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
}
function clearPendingLesson(dateStr) {
    const store = loadPending();
    delete store[dateStr];
    savePending(store);
}
function totalPendingCount(store) {
    return Object.values(store).reduce((sum, lesson)=>sum + lesson.items.length, 0);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/tabs/LessonsTab.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LessonsTab
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$volume$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Volume2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/volume-2.mjs [app-client] (ecmascript) <export default as Volume2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-right.mjs [app-client] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$marked$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookMarked$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/book-marked.mjs [app-client] (ecmascript) <export default as BookMarked>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.mjs [app-client] (ecmascript) <export default as X>");
;
var _s = __turbopack_context__.k.signature();
// Lessons tab — browse lessons by date, read context stories with interactive vocab tooltips
'use client';
;
;
function LessonsTab({ lessons, vocabulary, speakHanzi }) {
    _s();
    const [selectedLesson, setSelectedLesson] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [activeTooltip, setActiveTooltip] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const renderInteractiveStory = (text)=>{
        if (!text) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-secondary italic",
            children: "No context story provided for this lesson."
        }, void 0, false, {
            fileName: "[project]/src/components/tabs/LessonsTab.tsx",
            lineNumber: 26,
            columnNumber: 23
        }, this);
        const sortedVocab = [
            ...vocabulary
        ].sort((a, b)=>b.hanzi.length - a.hanzi.length);
        const foundVocabs = sortedVocab.filter((v)=>text.includes(v.hanzi));
        if (foundVocabs.length === 0) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-primary",
                style: {
                    lineHeight: '1.8',
                    whiteSpace: 'pre-line'
                },
                children: text
            }, void 0, false, {
                fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                lineNumber: 32,
                columnNumber: 14
            }, this);
        }
        const parts = text.split('\n\n');
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                lineHeight: '1.8',
                whiteSpace: 'pre-line'
            },
            children: parts.map((part, pIdx)=>{
                let currentSegment = part;
                const segmentElements = [];
                let keyCounter = 0;
                while(currentSegment.length > 0){
                    let earliestMatch = null;
                    for (const v of foundVocabs){
                        const idx = currentSegment.indexOf(v.hanzi);
                        if (idx !== -1 && (!earliestMatch || idx < earliestMatch.index)) {
                            earliestMatch = {
                                index: idx,
                                word: v
                            };
                        }
                    }
                    if (earliestMatch) {
                        const { index, word } = earliestMatch;
                        if (index > 0) {
                            segmentElements.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: currentSegment.substring(0, index)
                            }, `txt-${keyCounter++}`, false, {
                                fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                lineNumber: 56,
                                columnNumber: 38
                            }, this));
                        }
                        segmentElements.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            onClick: ()=>{
                                setActiveTooltip(word);
                                speakHanzi(word.hanzi);
                            },
                            style: {
                                color: 'var(--primary)',
                                borderBottom: '1px dotted var(--primary)',
                                cursor: 'pointer',
                                fontWeight: 500,
                                padding: '0 2px'
                            },
                            children: word.hanzi
                        }, `wd-${keyCounter++}`, false, {
                            fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                            lineNumber: 59,
                            columnNumber: 17
                        }, this));
                        currentSegment = currentSegment.substring(index + word.hanzi.length);
                    } else {
                        segmentElements.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: currentSegment
                        }, `txt-${keyCounter++}`, false, {
                            fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                            lineNumber: 75,
                            columnNumber: 36
                        }, this));
                        break;
                    }
                }
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    style: {
                        marginBottom: '16px'
                    },
                    children: segmentElements
                }, `p-${pIdx}`, false, {
                    fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                    lineNumber: 80,
                    columnNumber: 18
                }, this);
            })
        }, void 0, false, {
            fileName: "[project]/src/components/tabs/LessonsTab.tsx",
            lineNumber: 37,
            columnNumber: 7
        }, this);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "animate-fade-in",
        children: [
            selectedLesson ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>{
                            setSelectedLesson(null);
                            setActiveTooltip(null);
                        },
                        style: {
                            fontSize: '13px',
                            color: 'var(--text-secondary)',
                            marginBottom: '16px',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '4px'
                        },
                        children: "← Back to lessons"
                    }, void 0, false, {
                        fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                        lineNumber: 90,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            padding: '20px',
                            borderRadius: 'var(--radius-lg)',
                            border: '1px solid var(--border)',
                            backgroundColor: 'var(--bg-surface)',
                            boxShadow: 'var(--shadow-sm)',
                            marginBottom: '20px'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                style: {
                                    fontSize: '20px',
                                    fontWeight: 700,
                                    marginBottom: '8px'
                                },
                                children: [
                                    "Lesson on ",
                                    new Date(selectedLesson.date).toLocaleDateString(undefined, {
                                        weekday: 'long',
                                        year: 'numeric',
                                        month: 'long',
                                        day: 'numeric'
                                    })
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                lineNumber: 105,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                style: {
                                    fontSize: '11px',
                                    color: 'var(--text-muted)',
                                    display: 'block',
                                    marginBottom: '16px'
                                },
                                children: [
                                    vocabulary.filter((v)=>v.lesson_id === selectedLesson.id).length,
                                    " Vocabulary items"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                lineNumber: 110,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("hr", {
                                style: {
                                    border: 0,
                                    borderTop: '1px solid var(--border)',
                                    marginBottom: '16px'
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                lineNumber: 113,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                style: {
                                    fontSize: '14px',
                                    fontWeight: 600,
                                    color: 'var(--text-secondary)',
                                    marginBottom: '12px'
                                },
                                children: "Tutor Story & Context"
                            }, void 0, false, {
                                fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                lineNumber: 114,
                                columnNumber: 13
                            }, this),
                            renderInteractiveStory(selectedLesson.context_text)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                        lineNumber: 97,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        style: {
                            fontSize: '14px',
                            fontWeight: 600,
                            color: 'var(--text-secondary)',
                            marginBottom: '12px',
                            marginTop: '24px'
                        },
                        children: "Lesson Vocabulary List"
                    }, void 0, false, {
                        fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                        lineNumber: 120,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: 'flex',
                            flexDirection: 'column',
                            gap: '8px'
                        },
                        children: vocabulary.filter((v)=>v.lesson_id === selectedLesson.id).map((vocab)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    padding: '14px 16px',
                                    borderRadius: 'var(--radius-md)',
                                    border: '1px solid var(--border)',
                                    backgroundColor: 'var(--bg-surface)',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'space-between',
                                    gap: '12px'
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: {
                                            flex: 1
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    gap: '8px'
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        style: {
                                                            fontSize: '18px',
                                                            fontWeight: 600,
                                                            color: 'var(--text-primary)'
                                                        },
                                                        children: vocab.hanzi
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                                        lineNumber: 142,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        style: {
                                                            fontSize: '13px',
                                                            color: 'var(--text-secondary)',
                                                            fontStyle: 'italic'
                                                        },
                                                        children: vocab.pinyin
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                                        lineNumber: 143,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                                lineNumber: 141,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                style: {
                                                    fontSize: '13px',
                                                    color: 'var(--text-muted)',
                                                    marginTop: '4px'
                                                },
                                                children: vocab.translation
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                                lineNumber: 145,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                        lineNumber: 140,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>speakHanzi(vocab.hanzi),
                                        className: "tap-active",
                                        style: {
                                            padding: '8px',
                                            borderRadius: '50%',
                                            backgroundColor: 'var(--bg-app)',
                                            color: 'var(--text-secondary)'
                                        },
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$volume$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Volume2$3e$__["Volume2"], {
                                            size: 16
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                            lineNumber: 152,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                        lineNumber: 147,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, vocab.id, true, {
                                fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                lineNumber: 127,
                                columnNumber: 17
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                        lineNumber: 123,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                lineNumber: 89,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        style: {
                            fontSize: '20px',
                            fontWeight: 700,
                            letterSpacing: '-0.02em',
                            marginBottom: '4px'
                        },
                        children: "Your Tutor Lessons"
                    }, void 0, false, {
                        fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                        lineNumber: 160,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        style: {
                            fontSize: '13px',
                            color: 'var(--text-secondary)',
                            marginBottom: '20px'
                        },
                        children: "Sync the Google Doc to pull new lessons. Tap a lesson to read."
                    }, void 0, false, {
                        fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                        lineNumber: 163,
                        columnNumber: 11
                    }, this),
                    lessons.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            padding: '40px 20px',
                            borderRadius: 'var(--radius-lg)',
                            border: '1px solid var(--border)',
                            textAlign: 'center',
                            backgroundColor: 'var(--bg-surface)'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$marked$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookMarked$3e$__["BookMarked"], {
                                size: 36,
                                style: {
                                    color: 'var(--text-muted)',
                                    margin: '0 auto 12px auto'
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                lineNumber: 175,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                style: {
                                    fontSize: '14px',
                                    fontWeight: 500
                                },
                                children: "No vocabulary data loaded yet."
                            }, void 0, false, {
                                fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                lineNumber: 176,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                style: {
                                    fontSize: '12px',
                                    color: 'var(--text-muted)',
                                    marginTop: '6px',
                                    maxWidth: '280px',
                                    margin: '6px auto 0 auto'
                                },
                                children: 'Click the "Sync Doc" button at the top right to parse and download vocabulary from your teacher\'s doc.'
                            }, void 0, false, {
                                fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                lineNumber: 177,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                        lineNumber: 168,
                        columnNumber: 13
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: 'flex',
                            flexDirection: 'column',
                            gap: '10px'
                        },
                        children: lessons.map((lesson)=>{
                            const count = vocabulary.filter((v)=>v.lesson_id === lesson.id).length;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                onClick: ()=>setSelectedLesson(lesson),
                                className: "tap-active",
                                style: {
                                    padding: '16px',
                                    borderRadius: 'var(--radius-lg)',
                                    border: '1px solid var(--border)',
                                    backgroundColor: 'var(--bg-surface)',
                                    cursor: 'pointer',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'space-between',
                                    transition: 'border var(--transition-fast)'
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                style: {
                                                    fontSize: '15px',
                                                    fontWeight: 600,
                                                    color: 'var(--text-primary)'
                                                },
                                                children: new Date(lesson.date).toLocaleDateString(undefined, {
                                                    weekday: 'short',
                                                    month: 'short',
                                                    day: 'numeric',
                                                    year: 'numeric'
                                                })
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                                lineNumber: 203,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                style: {
                                                    display: 'block',
                                                    fontSize: '11px',
                                                    color: 'var(--text-muted)',
                                                    marginTop: '4px'
                                                },
                                                children: [
                                                    count,
                                                    " vocabulary items synced"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                                lineNumber: 208,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                        lineNumber: 202,
                                        columnNumber: 21
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                        size: 16,
                                        style: {
                                            color: 'var(--text-muted)'
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                        lineNumber: 212,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, lesson.id, true, {
                                fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                lineNumber: 186,
                                columnNumber: 19
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                        lineNumber: 182,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                lineNumber: 159,
                columnNumber: 9
            }, this),
            activeTooltip && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'fixed',
                    bottom: '84px',
                    left: '16px',
                    right: '16px',
                    padding: '16px',
                    borderRadius: 'var(--radius-lg)',
                    border: '1px solid var(--border)',
                    backgroundColor: 'var(--bg-surface)',
                    boxShadow: 'var(--shadow-lg)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    gap: '12px',
                    animation: 'fadeIn var(--transition-fast) forwards',
                    zIndex: 100
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '6px'
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        style: {
                                            fontSize: '20px',
                                            fontWeight: 700
                                        },
                                        children: activeTooltip.hanzi
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                        lineNumber: 242,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        style: {
                                            fontSize: '13px',
                                            fontStyle: 'italic',
                                            color: 'var(--text-secondary)'
                                        },
                                        children: activeTooltip.pinyin
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                        lineNumber: 243,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                lineNumber: 241,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                style: {
                                    fontSize: '13px',
                                    color: 'var(--text-muted)',
                                    marginTop: '4px'
                                },
                                children: activeTooltip.translation
                            }, void 0, false, {
                                fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                lineNumber: 245,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                        lineNumber: 240,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: 'flex',
                            alignItems: 'center',
                            gap: '6px'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>speakHanzi(activeTooltip.hanzi),
                                className: "tap-active",
                                style: {
                                    padding: '8px',
                                    borderRadius: '50%',
                                    backgroundColor: 'var(--bg-app)',
                                    color: 'var(--text-secondary)'
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$volume$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Volume2$3e$__["Volume2"], {
                                    size: 16
                                }, void 0, false, {
                                    fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                    lineNumber: 253,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                lineNumber: 248,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setActiveTooltip(null),
                                style: {
                                    padding: '8px',
                                    borderRadius: '50%',
                                    color: 'var(--text-muted)'
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                    size: 16
                                }, void 0, false, {
                                    fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                    lineNumber: 259,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                                lineNumber: 255,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                        lineNumber: 247,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/tabs/LessonsTab.tsx",
                lineNumber: 223,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/tabs/LessonsTab.tsx",
        lineNumber: 87,
        columnNumber: 5
    }, this);
}
_s(LessonsTab, "052umpqwc0PLzgDSdrooWJQuq80=");
_c = LessonsTab;
var _c;
__turbopack_context__.k.register(_c, "LessonsTab");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/srs.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// SM-2 spaced repetition algorithm — calculates next review interval and ease factor after each card grade
__turbopack_context__.s([
    "calculateSRS",
    ()=>calculateSRS
]);
function calculateSRS(quality, currentState) {
    let { interval, easeFactor, repetitions } = currentState;
    // Bound quality between 1 and 5
    quality = Math.max(1, Math.min(5, quality));
    // Determine repetitions and interval based on response quality
    if (quality < 3) {
        // Incorrect answer: restart the learning cycle
        repetitions = 0;
        interval = 1; // Show again tomorrow
    } else {
        // Correct answer: increment repetitions and scale interval
        if (repetitions === 0) {
            interval = 1; // 1 day
        } else if (repetitions === 1) {
            interval = 4; // 4 days (slightly accelerated for tutoring context)
        } else {
            interval = Math.round(interval * easeFactor);
        }
        repetitions += 1;
    }
    // Adjust Ease Factor (EF)
    // Standard formula: EF' = EF + (0.1 - (5 - Q) * (0.08 + (5 - Q) * 0.02))
    const qDiff = 5 - quality;
    easeFactor = easeFactor + (0.1 - qDiff * (0.08 + qDiff * 0.02));
    // Ease Factor must not fall below 1.3
    easeFactor = Math.max(1.3, parseFloat(easeFactor.toFixed(2)));
    // Determine user-facing mastery status
    let status = 'LEARNING';
    if (repetitions === 0) {
        status = 'NEW';
    } else if (interval >= 21) {
        status = 'MASTERED';
    } else if (interval >= 7) {
        status = 'REVIEW';
    }
    // Calculate next review timestamp
    const nextReview = new Date();
    nextReview.setDate(nextReview.getDate() + interval);
    // Standardize to the beginning of that day for clean daily sessions
    nextReview.setHours(0, 0, 0, 0);
    return {
        interval,
        easeFactor,
        repetitions,
        nextReview,
        status
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/tabs/FlashcardsTab.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FlashcardsTab
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$volume$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Volume2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/volume-2.mjs [app-client] (ecmascript) <export default as Volume2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Award$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/award.mjs [app-client] (ecmascript) <export default as Award>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$srs$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/srs.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
// Flashcards tab — SM-2 spaced repetition review session
'use client';
;
;
;
function FlashcardsTab({ vocabulary, lessons, studyProgress, onSave, speakHanzi }) {
    _s();
    const [isFlipped, setIsFlipped] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [reviewQueue, setReviewQueue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [currentQueueIndex, setCurrentQueueIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [reviewMode, setReviewMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('due');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FlashcardsTab.useEffect": ()=>{
            buildReviewQueue();
        }
    }["FlashcardsTab.useEffect"], [
        vocabulary,
        studyProgress,
        reviewMode
    ]);
    const buildReviewQueue = ()=>{
        const now = new Date();
        const dueVocab = vocabulary.filter((v)=>{
            const prog = studyProgress[v.hanzi];
            if (!prog) return true;
            return new Date(prog.nextReview) <= now;
        });
        if (reviewMode === 'due') {
            dueVocab.sort((a, b)=>{
                const progA = studyProgress[a.hanzi];
                const progB = studyProgress[b.hanzi];
                if (!progA && !progB) return 0;
                if (!progA) return -1;
                if (!progB) return 1;
                return new Date(progA.nextReview).getTime() - new Date(progB.nextReview).getTime();
            });
            setReviewQueue(dueVocab);
        } else {
            setReviewQueue([
                ...vocabulary
            ].sort(()=>0.5 - Math.random()));
        }
        setCurrentQueueIndex(0);
        setIsFlipped(false);
    };
    const handleGradeSRS = (grade)=>{
        if (reviewQueue.length === 0) return;
        const currentWord = reviewQueue[currentQueueIndex];
        const currentSRS = studyProgress[currentWord.hanzi] || {
            interval: 0,
            easeFactor: 2.5,
            repetitions: 0
        };
        const nextSRS = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$srs$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateSRS"])(grade, currentSRS);
        const updatedProgress = {
            ...studyProgress
        };
        updatedProgress[currentWord.hanzi] = {
            interval: nextSRS.interval,
            easeFactor: nextSRS.easeFactor,
            repetitions: nextSRS.repetitions,
            nextReview: nextSRS.nextReview.toISOString(),
            status: nextSRS.status,
            incorrect_count: (studyProgress[currentWord.hanzi]?.incorrect_count || 0) + (grade < 3 ? 1 : 0)
        };
        // Record today for streak tracking
        const studyDates = JSON.parse(localStorage.getItem('ch_study_dates') || '[]');
        const todayStr = new Date().toDateString();
        if (!studyDates.includes(todayStr)) {
            studyDates.push(todayStr);
            localStorage.setItem('ch_study_dates', JSON.stringify(studyDates));
        }
        onSave(lessons, vocabulary, updatedProgress);
        setIsFlipped(false);
        setTimeout(()=>{
            if (currentQueueIndex + 1 < reviewQueue.length) {
                setCurrentQueueIndex(currentQueueIndex + 1);
            } else {
                setReviewQueue([]);
            }
        }, 200);
    };
    const dueCount = vocabulary.filter((v)=>{
        const prog = studyProgress[v.hanzi];
        return !prog || new Date(prog.nextReview) <= new Date();
    }).length;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "animate-fade-in",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    marginBottom: '20px'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                style: {
                                    fontSize: '20px',
                                    fontWeight: 700
                                },
                                children: "Active Reviews"
                            }, void 0, false, {
                                fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                                lineNumber: 101,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                style: {
                                    fontSize: '12px',
                                    color: 'var(--text-muted)',
                                    marginTop: '2px'
                                },
                                children: reviewMode === 'due' ? 'Showing only due vocabulary' : 'Reviewing all loaded words'
                            }, void 0, false, {
                                fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                                lineNumber: 102,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                        lineNumber: 100,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: reviewMode,
                        onChange: (e)=>setReviewMode(e.target.value),
                        style: {
                            padding: '6px 12px',
                            borderRadius: 'var(--radius-sm)',
                            border: '1px solid var(--border)',
                            backgroundColor: 'var(--bg-surface)',
                            fontSize: '12px',
                            fontWeight: 500,
                            outline: 'none'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "due",
                                children: [
                                    "Due Cards (",
                                    dueCount,
                                    ")"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                                lineNumber: 114,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "all",
                                children: [
                                    "All Words (",
                                    vocabulary.length,
                                    ")"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                                lineNumber: 115,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                        lineNumber: 106,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                lineNumber: 99,
                columnNumber: 7
            }, this),
            reviewQueue.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    padding: '40px 20px',
                    borderRadius: 'var(--radius-lg)',
                    border: '1px solid var(--border)',
                    textAlign: 'center',
                    backgroundColor: 'var(--bg-surface)',
                    boxShadow: 'var(--shadow-sm)'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Award$3e$__["Award"], {
                        size: 36,
                        style: {
                            color: 'var(--primary)',
                            margin: '0 auto 12px auto'
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                        lineNumber: 124,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        style: {
                            fontSize: '14px',
                            fontWeight: 600
                        },
                        children: "Your review stack is fully clear."
                    }, void 0, false, {
                        fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                        lineNumber: 125,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        style: {
                            fontSize: '12px',
                            color: 'var(--text-muted)',
                            marginTop: '6px',
                            maxWidth: '280px',
                            margin: '6px auto 16px auto'
                        },
                        children: "You have studied all cards due for today. Keep up the high retention streak."
                    }, void 0, false, {
                        fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                        lineNumber: 126,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>{
                            setReviewMode('all');
                            buildReviewQueue();
                        },
                        className: "tap-active",
                        style: {
                            padding: '8px 16px',
                            borderRadius: 'var(--radius-md)',
                            border: '1px solid var(--border)',
                            fontSize: '12px',
                            fontWeight: 500,
                            backgroundColor: 'var(--bg-app)'
                        },
                        children: "Review all cards anyway"
                    }, void 0, false, {
                        fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                        lineNumber: 129,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                lineNumber: 120,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            marginBottom: '14px',
                            fontSize: '12px',
                            color: 'var(--text-secondary)'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    "Card ",
                                    currentQueueIndex + 1,
                                    " of ",
                                    reviewQueue.length
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                                lineNumber: 146,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    Math.round(currentQueueIndex / reviewQueue.length * 100),
                                    "% complete"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                                lineNumber: 147,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                        lineNumber: 142,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            width: '100%',
                            height: '4px',
                            borderRadius: '2px',
                            backgroundColor: 'var(--border)',
                            marginBottom: '24px',
                            overflow: 'hidden'
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                width: `${currentQueueIndex / reviewQueue.length * 100}%`,
                                height: '100%',
                                backgroundColor: 'var(--primary)',
                                transition: 'width var(--transition-fast)'
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                            lineNumber: 154,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                        lineNumber: 150,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `flip-container ${isFlipped ? 'flipped' : ''}`,
                        onClick: ()=>{
                            setIsFlipped(!isFlipped);
                            if (!isFlipped) speakHanzi(reviewQueue[currentQueueIndex].hanzi);
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flip-card-inner",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flip-card-front",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            style: {
                                                fontSize: '48px',
                                                fontWeight: 700,
                                                color: 'var(--text-primary)'
                                            },
                                            children: reviewQueue[currentQueueIndex].hanzi
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                                            lineNumber: 166,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            style: {
                                                fontSize: '11px',
                                                color: 'var(--text-muted)',
                                                marginTop: '28px',
                                                letterSpacing: '0.05em',
                                                textTransform: 'uppercase'
                                            },
                                            children: "Tap to reveal"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                                            lineNumber: 169,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                                    lineNumber: 165,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flip-card-back",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: (e)=>{
                                                e.stopPropagation();
                                                speakHanzi(reviewQueue[currentQueueIndex].hanzi);
                                            },
                                            style: {
                                                padding: '6px 10px',
                                                borderRadius: 'var(--radius-sm)',
                                                border: '1px solid var(--border)',
                                                backgroundColor: 'var(--bg-app)',
                                                fontSize: '12px',
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: '6px',
                                                color: 'var(--text-secondary)',
                                                marginBottom: '16px'
                                            },
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$volume$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Volume2$3e$__["Volume2"], {
                                                    size: 14
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                                                    lineNumber: 186,
                                                    columnNumber: 19
                                                }, this),
                                                " Pronounce"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                                            lineNumber: 178,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            style: {
                                                fontSize: '32px',
                                                fontWeight: 700,
                                                color: 'var(--text-primary)'
                                            },
                                            children: reviewQueue[currentQueueIndex].hanzi
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                                            lineNumber: 188,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            style: {
                                                fontSize: '18px',
                                                fontStyle: 'italic',
                                                color: 'var(--text-secondary)',
                                                marginTop: '4px',
                                                fontWeight: 500
                                            },
                                            children: reviewQueue[currentQueueIndex].pinyin
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                                            lineNumber: 191,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            style: {
                                                fontSize: '15px',
                                                color: 'var(--text-muted)',
                                                marginTop: '16px',
                                                maxWidth: '240px',
                                                lineHeight: 1.4
                                            },
                                            children: reviewQueue[currentQueueIndex].translation
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                                            lineNumber: 194,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                                    lineNumber: 177,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                            lineNumber: 164,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                        lineNumber: 160,
                        columnNumber: 11
                    }, this),
                    isFlipped ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "animate-fade-in",
                        style: {
                            marginTop: '24px'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                style: {
                                    fontSize: '12px',
                                    color: 'var(--text-secondary)',
                                    textAlign: 'center',
                                    marginBottom: '12px',
                                    fontWeight: 500
                                },
                                children: "How well did you remember this card?"
                            }, void 0, false, {
                                fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                                lineNumber: 203,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    display: 'grid',
                                    gridTemplateColumns: 'repeat(5, 1fr)',
                                    gap: '6px'
                                },
                                children: [
                                    1,
                                    2,
                                    3,
                                    4,
                                    5
                                ].map((grade)=>{
                                    const labels = [
                                        'Forgot',
                                        'Failed',
                                        'Hard',
                                        'Good',
                                        'Easy'
                                    ];
                                    const colors = [
                                        '#ef4444',
                                        '#f97316',
                                        '#eab308',
                                        '#3b82f6',
                                        '#10b981'
                                    ];
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: (e)=>{
                                            e.stopPropagation();
                                            handleGradeSRS(grade);
                                        },
                                        className: "tap-active",
                                        style: {
                                            padding: '10px 4px',
                                            borderRadius: 'var(--radius-md)',
                                            border: '1px solid var(--border)',
                                            backgroundColor: 'var(--bg-surface)',
                                            fontSize: '11px',
                                            fontWeight: 600,
                                            display: 'flex',
                                            flexDirection: 'column',
                                            alignItems: 'center',
                                            gap: '4px'
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                style: {
                                                    color: colors[grade - 1],
                                                    fontSize: '15px',
                                                    fontWeight: 700
                                                },
                                                children: grade
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                                                lineNumber: 224,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                style: {
                                                    color: 'var(--text-secondary)',
                                                    fontSize: '9px'
                                                },
                                                children: labels[grade - 1]
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                                                lineNumber: 225,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, grade, true, {
                                        fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                                        lineNumber: 214,
                                        columnNumber: 21
                                    }, this);
                                })
                            }, void 0, false, {
                                fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                                lineNumber: 209,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                        lineNumber: 202,
                        columnNumber: 13
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        style: {
                            fontSize: '12px',
                            color: 'var(--text-muted)',
                            textAlign: 'center',
                            marginTop: '24px',
                            fontStyle: 'italic'
                        },
                        children: "Tip: Read the Hanzi aloud, guess the meaning, then tap to check."
                    }, void 0, false, {
                        fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                        lineNumber: 232,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
                lineNumber: 141,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/tabs/FlashcardsTab.tsx",
        lineNumber: 98,
        columnNumber: 5
    }, this);
}
_s(FlashcardsTab, "ihIqtxfBLvdmCFzdBJwmNwfH7SI=");
_c = FlashcardsTab;
var _c;
__turbopack_context__.k.register(_c, "FlashcardsTab");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/tabs/PracticeTab.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PracticeTab
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$volume$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Volume2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/volume-2.mjs [app-client] (ecmascript) <export default as Volume2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/check.mjs [app-client] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.mjs [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-alert.mjs [app-client] (ecmascript) <export default as AlertCircle>");
;
var _s = __turbopack_context__.k.signature();
// Practice tab — tone guessing and multiple choice vocabulary games
'use client';
;
;
function getToneNumber(pinyin) {
    if (/[āēīōūǖ]/i.test(pinyin)) return 1;
    if (/[áéíóúǘ]/i.test(pinyin)) return 2;
    if (/[ǎěǐǒǔǚ]/i.test(pinyin)) return 3;
    if (/[àèìòùǜ]/i.test(pinyin)) return 4;
    return 5;
}
function PracticeTab({ vocabulary, lessons, studyProgress, onSave, speakHanzi }) {
    _s();
    const [toneGameWord, setToneGameWord] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [toneFeedback, setToneFeedback] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [mcWord, setMcWord] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [mcOptions, setMcOptions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [mcFeedback, setMcFeedback] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PracticeTab.useEffect": ()=>{
            if (vocabulary.length > 0) {
                pickNewToneWord();
                pickNewMcWord();
            }
        }
    }["PracticeTab.useEffect"], []);
    const pickNewToneWord = ()=>{
        if (vocabulary.length === 0) return;
        const eligible = vocabulary.filter((v)=>v.pinyin && /[āáǎàēéěèīíǐìōóǒòūúǔùüǘǚǜū]/i.test(v.pinyin));
        const pool = eligible.length > 0 ? eligible : vocabulary;
        setToneGameWord(pool[Math.floor(Math.random() * pool.length)]);
        setToneFeedback(null);
    };
    const pickNewMcWord = ()=>{
        if (vocabulary.length === 0) return;
        const randomWord = vocabulary[Math.floor(Math.random() * vocabulary.length)];
        const otherTranslations = vocabulary.filter((v)=>v.id !== randomWord.id).map((v)=>v.translation).filter((val, idx, self)=>self.indexOf(val) === idx);
        const options = [
            randomWord.translation,
            ...otherTranslations.sort(()=>0.5 - Math.random()).slice(0, 3)
        ].sort(()=>0.5 - Math.random());
        setMcWord(randomWord);
        setMcOptions(options);
        setMcFeedback(null);
    };
    const handleToneSelection = (toneNum)=>{
        if (!toneGameWord || toneFeedback) return;
        const correctTone = getToneNumber(toneGameWord.pinyin);
        const isCorrect = toneNum === correctTone;
        if (!isCorrect) {
            const updatedProgress = {
                ...studyProgress
            };
            if (updatedProgress[toneGameWord.hanzi]) {
                updatedProgress[toneGameWord.hanzi].incorrect_count += 1;
                onSave(lessons, vocabulary, updatedProgress);
            }
        }
        setToneFeedback({
            isCorrect,
            selected: toneNum
        });
    };
    const handleMcSelection = (option)=>{
        if (!mcWord || mcFeedback) return;
        const isCorrect = option === mcWord.translation;
        if (!isCorrect) {
            const updatedProgress = {
                ...studyProgress
            };
            if (updatedProgress[mcWord.hanzi]) {
                updatedProgress[mcWord.hanzi].incorrect_count += 1;
                onSave(lessons, vocabulary, updatedProgress);
            }
        }
        setMcFeedback({
            isCorrect,
            selected: option
        });
    };
    if (vocabulary.length < 5) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "animate-fade-in",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    style: {
                        fontSize: '20px',
                        fontWeight: 700,
                        letterSpacing: '-0.02em',
                        marginBottom: '4px'
                    },
                    children: "Practice Games"
                }, void 0, false, {
                    fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                    lineNumber: 93,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    style: {
                        fontSize: '13px',
                        color: 'var(--text-secondary)',
                        marginBottom: '20px'
                    },
                    children: "Choose a quick-fire training game to strengthen tone recognition and vocabulary matching."
                }, void 0, false, {
                    fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                    lineNumber: 94,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        padding: '40px 20px',
                        borderRadius: 'var(--radius-lg)',
                        border: '1px solid var(--border)',
                        textAlign: 'center',
                        backgroundColor: 'var(--bg-surface)'
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__["AlertCircle"], {
                            size: 36,
                            style: {
                                color: 'var(--text-muted)',
                                margin: '0 auto 12px auto'
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                            lineNumber: 101,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            style: {
                                fontSize: '14px',
                                fontWeight: 500
                            },
                            children: "Not enough vocabulary loaded."
                        }, void 0, false, {
                            fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                            lineNumber: 102,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            style: {
                                fontSize: '12px',
                                color: 'var(--text-muted)',
                                marginTop: '6px'
                            },
                            children: "Please sync at least 5 words from the Google Doc to unlock active training games."
                        }, void 0, false, {
                            fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                            lineNumber: 103,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                    lineNumber: 97,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/tabs/PracticeTab.tsx",
            lineNumber: 92,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "animate-fade-in",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                style: {
                    fontSize: '20px',
                    fontWeight: 700,
                    letterSpacing: '-0.02em',
                    marginBottom: '4px'
                },
                children: "Practice Games"
            }, void 0, false, {
                fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                lineNumber: 113,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                style: {
                    fontSize: '13px',
                    color: 'var(--text-secondary)',
                    marginBottom: '20px'
                },
                children: "Choose a quick-fire training game to strengthen tone recognition and vocabulary matching."
            }, void 0, false, {
                fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                lineNumber: 114,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '24px'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            padding: '20px',
                            borderRadius: 'var(--radius-lg)',
                            border: '1px solid var(--border)',
                            backgroundColor: 'var(--bg-surface)',
                            boxShadow: 'var(--shadow-sm)'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px',
                                    marginBottom: '14px'
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        style: {
                                            padding: '4px 8px',
                                            borderRadius: 'var(--radius-sm)',
                                            backgroundColor: 'var(--primary-subtle)',
                                            color: 'var(--primary)',
                                            fontSize: '11px',
                                            fontWeight: 600
                                        },
                                        children: "Game 1"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                        lineNumber: 126,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        style: {
                                            fontSize: '15px',
                                            fontWeight: 700
                                        },
                                        children: "Mandarin Tone Practice"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                        lineNumber: 130,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                lineNumber: 125,
                                columnNumber: 11
                            }, this),
                            toneGameWord && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    textAlign: 'center'
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: {
                                            fontSize: '36px',
                                            fontWeight: 700,
                                            color: 'var(--text-primary)',
                                            marginBottom: '4px'
                                        },
                                        children: toneGameWord.hanzi
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                        lineNumber: 135,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        style: {
                                            fontSize: '13px',
                                            color: 'var(--text-muted)',
                                            marginBottom: '16px'
                                        },
                                        children: toneGameWord.translation
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                        lineNumber: 138,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: {
                                            display: 'grid',
                                            gridTemplateColumns: 'repeat(5, 1fr)',
                                            gap: '6px',
                                            marginBottom: '16px'
                                        },
                                        children: [
                                            1,
                                            2,
                                            3,
                                            4,
                                            5
                                        ].map((tNum)=>{
                                            const toneSymbols = [
                                                '¯ (1)',
                                                '´ (2)',
                                                'ˇ (3)',
                                                '` (4)',
                                                '· (5)'
                                            ];
                                            const isCorrect = tNum === getToneNumber(toneGameWord.pinyin);
                                            const isSelected = toneFeedback?.selected === tNum;
                                            let btnBg = 'var(--bg-app)';
                                            let btnBorder = 'var(--border)';
                                            let btnTextColor = 'var(--text-primary)';
                                            if (toneFeedback) {
                                                if (isCorrect) {
                                                    btnBg = 'var(--success-subtle)';
                                                    btnBorder = 'var(--success)';
                                                    btnTextColor = 'var(--success)';
                                                } else if (isSelected) {
                                                    btnBg = 'var(--danger-subtle)';
                                                    btnBorder = 'var(--danger)';
                                                    btnTextColor = 'var(--danger)';
                                                }
                                            }
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                disabled: !!toneFeedback,
                                                onClick: ()=>handleToneSelection(tNum),
                                                className: "tap-active",
                                                style: {
                                                    padding: '12px 2px',
                                                    borderRadius: 'var(--radius-md)',
                                                    border: `1px solid ${btnBorder}`,
                                                    backgroundColor: btnBg,
                                                    color: btnTextColor,
                                                    fontSize: '11px',
                                                    fontWeight: 600
                                                },
                                                children: toneSymbols[tNum - 1]
                                            }, tNum, false, {
                                                fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                                lineNumber: 158,
                                                columnNumber: 21
                                            }, this);
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                        lineNumber: 142,
                                        columnNumber: 15
                                    }, this),
                                    toneFeedback ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "animate-fade-in",
                                        style: {
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            flexDirection: 'column',
                                            gap: '10px'
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    gap: '6px',
                                                    fontSize: '13px',
                                                    fontWeight: 600,
                                                    color: toneFeedback.isCorrect ? 'var(--success)' : 'var(--danger)'
                                                },
                                                children: toneFeedback.isCorrect ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                                            size: 16
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                                            lineNumber: 182,
                                                            columnNumber: 27
                                                        }, this),
                                                        " Perfect! Pronounced: ",
                                                        toneGameWord.pinyin
                                                    ]
                                                }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                            size: 16
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                                            lineNumber: 183,
                                                            columnNumber: 27
                                                        }, this),
                                                        " Incorrect. It is ",
                                                        toneGameWord.pinyin
                                                    ]
                                                }, void 0, true)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                                lineNumber: 177,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>speakHanzi(toneGameWord.hanzi),
                                                style: {
                                                    fontSize: '11px',
                                                    color: 'var(--text-secondary)',
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    gap: '4px',
                                                    textDecoration: 'underline'
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$volume$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Volume2$3e$__["Volume2"], {
                                                        size: 12
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                                        lineNumber: 189,
                                                        columnNumber: 21
                                                    }, this),
                                                    " Listen"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                                lineNumber: 185,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: pickNewToneWord,
                                                className: "tap-active",
                                                style: {
                                                    marginTop: '6px',
                                                    padding: '8px 16px',
                                                    borderRadius: 'var(--radius-md)',
                                                    backgroundColor: 'var(--text-primary)',
                                                    color: 'var(--bg-surface)',
                                                    fontSize: '12px',
                                                    fontWeight: 600
                                                },
                                                children: "Next Word"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                                lineNumber: 191,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                        lineNumber: 176,
                                        columnNumber: 17
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        style: {
                                            fontSize: '11px',
                                            color: 'var(--text-muted)',
                                            fontStyle: 'italic'
                                        },
                                        children: "Select the correct tone accent for this Hanzi character."
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                        lineNumber: 203,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                lineNumber: 134,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                        lineNumber: 121,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            padding: '20px',
                            borderRadius: 'var(--radius-lg)',
                            border: '1px solid var(--border)',
                            backgroundColor: 'var(--bg-surface)',
                            boxShadow: 'var(--shadow-sm)'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px',
                                    marginBottom: '14px'
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        style: {
                                            padding: '4px 8px',
                                            borderRadius: 'var(--radius-sm)',
                                            backgroundColor: 'var(--primary-subtle)',
                                            color: 'var(--primary)',
                                            fontSize: '11px',
                                            fontWeight: 600
                                        },
                                        children: "Game 2"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                        lineNumber: 217,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        style: {
                                            fontSize: '15px',
                                            fontWeight: 700
                                        },
                                        children: "Multiple Choice Match"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                        lineNumber: 221,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                lineNumber: 216,
                                columnNumber: 11
                            }, this),
                            mcWord && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    textAlign: 'center'
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: {
                                            fontSize: '36px',
                                            fontWeight: 700,
                                            color: 'var(--text-primary)',
                                            marginBottom: '4px'
                                        },
                                        children: mcWord.hanzi
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                        lineNumber: 226,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        style: {
                                            fontSize: '13px',
                                            color: 'var(--text-secondary)',
                                            fontStyle: 'italic',
                                            marginBottom: '16px'
                                        },
                                        children: mcWord.pinyin
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                        lineNumber: 229,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: {
                                            display: 'flex',
                                            flexDirection: 'column',
                                            gap: '8px',
                                            marginBottom: '16px'
                                        },
                                        children: mcOptions.map((opt, oIdx)=>{
                                            const isCorrect = opt === mcWord.translation;
                                            const isSelected = mcFeedback?.selected === opt;
                                            let btnBg = 'var(--bg-app)';
                                            let btnBorder = 'var(--border)';
                                            let btnTextColor = 'var(--text-primary)';
                                            if (mcFeedback) {
                                                if (isCorrect) {
                                                    btnBg = 'var(--success-subtle)';
                                                    btnBorder = 'var(--success)';
                                                    btnTextColor = 'var(--success)';
                                                } else if (isSelected) {
                                                    btnBg = 'var(--danger-subtle)';
                                                    btnBorder = 'var(--danger)';
                                                    btnTextColor = 'var(--danger)';
                                                }
                                            }
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                disabled: !!mcFeedback,
                                                onClick: ()=>handleMcSelection(opt),
                                                className: "tap-active",
                                                style: {
                                                    padding: '12px 16px',
                                                    borderRadius: 'var(--radius-md)',
                                                    border: `1px solid ${btnBorder}`,
                                                    backgroundColor: btnBg,
                                                    color: btnTextColor,
                                                    fontSize: '13px',
                                                    fontWeight: 500,
                                                    textAlign: 'left',
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    justifyContent: 'space-between'
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: opt
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                                        lineNumber: 260,
                                                        columnNumber: 23
                                                    }, this),
                                                    mcFeedback && isCorrect && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                                        size: 14
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                                        lineNumber: 261,
                                                        columnNumber: 51
                                                    }, this),
                                                    mcFeedback && isSelected && !isCorrect && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                        size: 14
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                                        lineNumber: 262,
                                                        columnNumber: 66
                                                    }, this)
                                                ]
                                            }, oIdx, true, {
                                                fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                                lineNumber: 248,
                                                columnNumber: 21
                                            }, this);
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                        lineNumber: 233,
                                        columnNumber: 15
                                    }, this),
                                    mcFeedback ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "animate-fade-in",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                style: {
                                                    fontSize: '13px',
                                                    fontWeight: 600,
                                                    marginBottom: '10px',
                                                    color: mcFeedback.isCorrect ? 'var(--success)' : 'var(--danger)'
                                                },
                                                children: mcFeedback.isCorrect ? 'Excellent! That is correct.' : `Incorrect. Correct: "${mcWord.translation}"`
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                                lineNumber: 270,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: pickNewMcWord,
                                                className: "tap-active",
                                                style: {
                                                    padding: '8px 16px',
                                                    borderRadius: 'var(--radius-md)',
                                                    backgroundColor: 'var(--text-primary)',
                                                    color: 'var(--bg-surface)',
                                                    fontSize: '12px',
                                                    fontWeight: 600
                                                },
                                                children: "Next Character"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                                lineNumber: 276,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                        lineNumber: 269,
                                        columnNumber: 17
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        style: {
                                            fontSize: '11px',
                                            color: 'var(--text-muted)',
                                            fontStyle: 'italic'
                                        },
                                        children: "Select the correct translation representing this Chinese character."
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                        lineNumber: 288,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                                lineNumber: 225,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                        lineNumber: 212,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/tabs/PracticeTab.tsx",
                lineNumber: 118,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/tabs/PracticeTab.tsx",
        lineNumber: 112,
        columnNumber: 5
    }, this);
}
_s(PracticeTab, "u+2B1lavxDOV8ZBKUlXsNNNJz48=");
_c = PracticeTab;
var _c;
__turbopack_context__.k.register(_c, "PracticeTab");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/tabs/StatsTab.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StatsTab
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$flame$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Flame$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/flame.mjs [app-client] (ecmascript) <export default as Flame>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/book-open.mjs [app-client] (ecmascript) <export default as BookOpen>");
// Stats tab — study streak, mastery breakdown, and toughest words
'use client';
;
;
function getStudyStreak() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    const studyDates = JSON.parse(localStorage.getItem('ch_study_dates') || '[]');
    if (studyDates.length === 0) return 0;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    if (!studyDates.includes(today.toDateString()) && !studyDates.includes(yesterday.toDateString())) {
        return 0;
    }
    let streak = 0;
    const cursor = new Date(today);
    while(studyDates.includes(cursor.toDateString())){
        streak++;
        cursor.setDate(cursor.getDate() - 1);
    }
    return streak;
}
function StatsTab({ vocabulary, studyProgress }) {
    const newCount = vocabulary.filter((v)=>!studyProgress[v.hanzi] || studyProgress[v.hanzi].status === 'NEW').length;
    const learningCount = vocabulary.filter((v)=>studyProgress[v.hanzi]?.status === 'LEARNING').length;
    const reviewCount = vocabulary.filter((v)=>studyProgress[v.hanzi]?.status === 'REVIEW').length;
    const masteredCount = vocabulary.filter((v)=>studyProgress[v.hanzi]?.status === 'MASTERED').length;
    const totalStudied = vocabulary.length - newCount;
    const difficultWords = [
        ...vocabulary
    ].filter((v)=>studyProgress[v.hanzi] && studyProgress[v.hanzi].incorrect_count > 0).sort((a, b)=>(studyProgress[b.hanzi]?.incorrect_count || 0) - (studyProgress[a.hanzi]?.incorrect_count || 0)).slice(0, 5);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "animate-fade-in",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                style: {
                    fontSize: '20px',
                    fontWeight: 700,
                    letterSpacing: '-0.02em',
                    marginBottom: '4px'
                },
                children: "Study Progress Summary"
            }, void 0, false, {
                fileName: "[project]/src/components/tabs/StatsTab.tsx",
                lineNumber: 51,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                style: {
                    fontSize: '13px',
                    color: 'var(--text-secondary)',
                    marginBottom: '20px'
                },
                children: "Tracks memory scheduling indices, streaks, and difficult vocabulary."
            }, void 0, false, {
                fileName: "[project]/src/components/tabs/StatsTab.tsx",
                lineNumber: 54,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    display: 'grid',
                    gridTemplateColumns: '1fr 1fr',
                    gap: '10px',
                    marginBottom: '20px'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            padding: '16px',
                            borderRadius: 'var(--radius-lg)',
                            border: '1px solid var(--border)',
                            backgroundColor: 'var(--bg-surface)',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '12px'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    padding: '10px',
                                    borderRadius: '50%',
                                    backgroundColor: 'var(--danger-subtle)',
                                    color: 'var(--accent)'
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$flame$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Flame$3e$__["Flame"], {
                                    size: 20
                                }, void 0, false, {
                                    fileName: "[project]/src/components/tabs/StatsTab.tsx",
                                    lineNumber: 64,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/tabs/StatsTab.tsx",
                                lineNumber: 63,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        style: {
                                            fontSize: '20px',
                                            fontWeight: 700,
                                            display: 'block'
                                        },
                                        children: [
                                            getStudyStreak(),
                                            " Days"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/tabs/StatsTab.tsx",
                                        lineNumber: 67,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        style: {
                                            fontSize: '10px',
                                            color: 'var(--text-secondary)'
                                        },
                                        children: "Active Streak"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/tabs/StatsTab.tsx",
                                        lineNumber: 68,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/tabs/StatsTab.tsx",
                                lineNumber: 66,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/tabs/StatsTab.tsx",
                        lineNumber: 59,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            padding: '16px',
                            borderRadius: 'var(--radius-lg)',
                            border: '1px solid var(--border)',
                            backgroundColor: 'var(--bg-surface)',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '12px'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    padding: '10px',
                                    borderRadius: '50%',
                                    backgroundColor: 'var(--primary-subtle)',
                                    color: 'var(--primary)'
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__["BookOpen"], {
                                    size: 20
                                }, void 0, false, {
                                    fileName: "[project]/src/components/tabs/StatsTab.tsx",
                                    lineNumber: 77,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/tabs/StatsTab.tsx",
                                lineNumber: 76,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        style: {
                                            fontSize: '20px',
                                            fontWeight: 700,
                                            display: 'block'
                                        },
                                        children: [
                                            totalStudied,
                                            " / ",
                                            vocabulary.length
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/tabs/StatsTab.tsx",
                                        lineNumber: 80,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        style: {
                                            fontSize: '10px',
                                            color: 'var(--text-secondary)'
                                        },
                                        children: "Words Studied"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/tabs/StatsTab.tsx",
                                        lineNumber: 81,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/tabs/StatsTab.tsx",
                                lineNumber: 79,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/tabs/StatsTab.tsx",
                        lineNumber: 72,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/tabs/StatsTab.tsx",
                lineNumber: 58,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    padding: '20px',
                    borderRadius: 'var(--radius-lg)',
                    border: '1px solid var(--border)',
                    backgroundColor: 'var(--bg-surface)',
                    marginBottom: '20px',
                    boxShadow: 'var(--shadow-sm)'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        style: {
                            fontSize: '14px',
                            fontWeight: 700,
                            marginBottom: '14px'
                        },
                        children: "Retention Level Distribution"
                    }, void 0, false, {
                        fileName: "[project]/src/components/tabs/StatsTab.tsx",
                        lineNumber: 90,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: 'flex',
                            height: '16px',
                            borderRadius: '8px',
                            overflow: 'hidden',
                            backgroundColor: 'var(--bg-app)',
                            marginBottom: '20px'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    width: `${vocabulary.length > 0 ? masteredCount / vocabulary.length * 100 : 0}%`,
                                    backgroundColor: '#10b981'
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/tabs/StatsTab.tsx",
                                lineNumber: 96,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    width: `${vocabulary.length > 0 ? reviewCount / vocabulary.length * 100 : 0}%`,
                                    backgroundColor: '#3b82f6'
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/tabs/StatsTab.tsx",
                                lineNumber: 97,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    width: `${vocabulary.length > 0 ? learningCount / vocabulary.length * 100 : 0}%`,
                                    backgroundColor: '#eab308'
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/tabs/StatsTab.tsx",
                                lineNumber: 98,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    width: `${vocabulary.length > 0 ? newCount / vocabulary.length * 100 : 0}%`,
                                    backgroundColor: 'var(--border)'
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/tabs/StatsTab.tsx",
                                lineNumber: 99,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/tabs/StatsTab.tsx",
                        lineNumber: 92,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: 'grid',
                            gridTemplateColumns: '1fr 1fr',
                            gap: '12px',
                            fontSize: '12px'
                        },
                        children: [
                            {
                                label: `Mastered (${masteredCount})`,
                                color: '#10b981'
                            },
                            {
                                label: `Reviewing (${reviewCount})`,
                                color: '#3b82f6'
                            },
                            {
                                label: `Learning (${learningCount})`,
                                color: '#eab308'
                            },
                            {
                                label: `Unstudied (${newCount})`,
                                color: 'var(--border)'
                            }
                        ].map(({ label, color })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px'
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        style: {
                                            width: '10px',
                                            height: '10px',
                                            borderRadius: '50%',
                                            backgroundColor: color,
                                            flexShrink: 0
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/tabs/StatsTab.tsx",
                                        lineNumber: 110,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: label
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/tabs/StatsTab.tsx",
                                        lineNumber: 111,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, label, true, {
                                fileName: "[project]/src/components/tabs/StatsTab.tsx",
                                lineNumber: 109,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/components/tabs/StatsTab.tsx",
                        lineNumber: 102,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/tabs/StatsTab.tsx",
                lineNumber: 86,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    padding: '20px',
                    borderRadius: 'var(--radius-lg)',
                    border: '1px solid var(--border)',
                    backgroundColor: 'var(--bg-surface)'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        style: {
                            fontSize: '14px',
                            fontWeight: 700,
                            marginBottom: '12px'
                        },
                        children: "Target Review: Toughest Words"
                    }, void 0, false, {
                        fileName: "[project]/src/components/tabs/StatsTab.tsx",
                        lineNumber: 121,
                        columnNumber: 9
                    }, this),
                    difficultWords.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        style: {
                            fontSize: '12px',
                            color: 'var(--text-muted)',
                            fontStyle: 'italic',
                            textAlign: 'center',
                            padding: '10px 0'
                        },
                        children: "No difficult cards recorded. Your retention metrics are optimal."
                    }, void 0, false, {
                        fileName: "[project]/src/components/tabs/StatsTab.tsx",
                        lineNumber: 124,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: 'flex',
                            flexDirection: 'column',
                            gap: '8px'
                        },
                        children: difficultWords.map((word)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    padding: '10px 12px',
                                    borderRadius: 'var(--radius-sm)',
                                    backgroundColor: 'var(--bg-app)',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'space-between',
                                    fontSize: '13px'
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                style: {
                                                    fontWeight: 600,
                                                    color: 'var(--text-primary)'
                                                },
                                                children: word.hanzi
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/tabs/StatsTab.tsx",
                                                lineNumber: 139,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                style: {
                                                    color: 'var(--text-secondary)',
                                                    marginLeft: '6px',
                                                    fontSize: '11px'
                                                },
                                                children: [
                                                    "(",
                                                    word.pinyin,
                                                    ")"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/tabs/StatsTab.tsx",
                                                lineNumber: 140,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/tabs/StatsTab.tsx",
                                        lineNumber: 138,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        style: {
                                            fontSize: '11px',
                                            padding: '2px 6px',
                                            borderRadius: '4px',
                                            backgroundColor: 'var(--danger-subtle)',
                                            color: 'var(--danger)',
                                            fontWeight: 600
                                        },
                                        children: [
                                            studyProgress[word.hanzi]?.incorrect_count,
                                            " Failed guesses"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/tabs/StatsTab.tsx",
                                        lineNumber: 142,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, word.id, true, {
                                fileName: "[project]/src/components/tabs/StatsTab.tsx",
                                lineNumber: 130,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/components/tabs/StatsTab.tsx",
                        lineNumber: 128,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/tabs/StatsTab.tsx",
                lineNumber: 117,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/tabs/StatsTab.tsx",
        lineNumber: 50,
        columnNumber: 5
    }, this);
}
_c = StatsTab;
var _c;
__turbopack_context__.k.register(_c, "StatsTab");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/tabs/ReviewTab.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ReviewTab
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/check.mjs [app-client] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.mjs [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$volume$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Volume2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/volume-2.mjs [app-client] (ecmascript) <export default as Volume2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pencil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pencil$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/pencil.mjs [app-client] (ecmascript) <export default as Pencil>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clipboard$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ClipboardCheck$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/clipboard-check.mjs [app-client] (ecmascript) <export default as ClipboardCheck>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-right.mjs [app-client] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$pending$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/pending.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
// Review tab — inspect, edit, approve, or reject AI-parsed vocab before it enters the study bank
'use client';
;
;
;
function ReviewTab({ pendingStore, onPendingUpdate, lessons, vocabulary, studyProgress, onSave, speakHanzi }) {
    _s();
    const [reviewLesson, setReviewLesson] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [editingItem, setEditingItem] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [editHanzi, setEditHanzi] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [editPinyin, setEditPinyin] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [editTranslation, setEditTranslation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const approvePendingItem = (dateStr, itemId)=>{
        const store = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$pending$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadPending"])();
        const lesson = store[dateStr];
        if (!lesson) return;
        const item = lesson.items.find((i)=>i.id === itemId);
        if (!item) return;
        const lessonId = `l_${dateStr}`;
        const newVocab = {
            id: `v_${itemId}`,
            lesson_id: lessonId,
            hanzi: item.hanzi,
            pinyin: item.pinyin,
            translation: item.translation
        };
        const updatedLessons = [
            ...lessons
        ];
        if (!updatedLessons.find((l)=>l.id === lessonId)) {
            updatedLessons.unshift({
                id: lessonId,
                date: dateStr,
                context_text: ''
            });
            updatedLessons.sort((a, b)=>new Date(b.date).getTime() - new Date(a.date).getTime());
        }
        const updatedVocab = [
            ...vocabulary
        ];
        if (!updatedVocab.find((v)=>v.hanzi === item.hanzi && v.lesson_id === lessonId)) {
            updatedVocab.push(newVocab);
        }
        const updatedProgress = {
            ...studyProgress
        };
        if (!updatedProgress[item.hanzi]) {
            updatedProgress[item.hanzi] = {
                interval: 0,
                easeFactor: 2.5,
                repetitions: 0,
                nextReview: new Date().toISOString(),
                status: 'NEW',
                incorrect_count: 0
            };
        }
        onSave(updatedLessons, updatedVocab, updatedProgress);
        store[dateStr].items = store[dateStr].items.filter((i)=>i.id !== itemId);
        if (store[dateStr].items.length === 0) {
            delete store[dateStr];
            setReviewLesson(null);
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$pending$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["savePending"])(store);
        onPendingUpdate({
            ...store
        });
    };
    const approveAllInLesson = (dateStr)=>{
        const store = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$pending$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadPending"])();
        const lesson = store[dateStr];
        if (!lesson) return;
        // Snapshot item IDs since approving mutates the store
        const ids = lesson.items.map((i)=>i.id);
        ids.forEach((id)=>approvePendingItem(dateStr, id));
        setReviewLesson(null);
    };
    const rejectPendingItem = (dateStr, itemId)=>{
        const store = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$pending$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadPending"])();
        if (!store[dateStr]) return;
        store[dateStr].items = store[dateStr].items.filter((i)=>i.id !== itemId);
        if (store[dateStr].items.length === 0) delete store[dateStr];
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$pending$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["savePending"])(store);
        onPendingUpdate({
            ...store
        });
    };
    const saveItemEdit = (dateStr, itemId)=>{
        const store = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$pending$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadPending"])();
        const lesson = store[dateStr];
        if (!lesson) return;
        const item = lesson.items.find((i)=>i.id === itemId);
        if (!item) return;
        item.hanzi = editHanzi;
        item.pinyin = editPinyin;
        item.translation = editTranslation;
        item.confidence = 'high';
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$pending$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["savePending"])(store);
        onPendingUpdate({
            ...store
        });
        setEditingItem(null);
    };
    if (reviewLesson) {
        const lesson = pendingStore[reviewLesson];
        if (!lesson) return null;
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "animate-fade-in",
            style: {
                padding: '16px 16px 80px 16px'
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: ()=>{
                        setReviewLesson(null);
                        setEditingItem(null);
                    },
                    style: {
                        fontSize: '13px',
                        color: 'var(--text-secondary)',
                        marginBottom: '16px',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px'
                    },
                    children: "← Back to lessons"
                }, void 0, false, {
                    fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                    lineNumber: 115,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        marginBottom: '16px'
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    style: {
                                        fontSize: '17px',
                                        fontWeight: 700
                                    },
                                    children: new Date(lesson.date).toLocaleDateString(undefined, {
                                        month: 'short',
                                        day: 'numeric',
                                        year: 'numeric'
                                    })
                                }, void 0, false, {
                                    fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                    lineNumber: 124,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    style: {
                                        fontSize: '11px',
                                        color: 'var(--text-muted)',
                                        marginTop: '2px'
                                    },
                                    children: [
                                        lesson.items.length,
                                        " words pending · ",
                                        lesson.items.filter((i)=>i.confidence === 'low').length,
                                        " need attention"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                    lineNumber: 127,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                            lineNumber: 123,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>approveAllInLesson(reviewLesson),
                            className: "tap-active",
                            style: {
                                padding: '8px 14px',
                                borderRadius: 'var(--radius-sm)',
                                backgroundColor: 'var(--primary)',
                                color: '#fff',
                                fontSize: '12px',
                                fontWeight: 600,
                                display: 'flex',
                                alignItems: 'center',
                                gap: '6px'
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                    size: 13
                                }, void 0, false, {
                                    fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                    lineNumber: 140,
                                    columnNumber: 13
                                }, this),
                                " Approve All"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                            lineNumber: 131,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                    lineNumber: 122,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '8px'
                    },
                    children: lesson.items.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                padding: '14px',
                                borderRadius: 'var(--radius-md)',
                                border: `1px solid ${item.confidence === 'low' ? 'var(--accent)' : 'var(--border)'}`,
                                backgroundColor: item.confidence === 'low' ? 'rgba(217,119,6,0.06)' : 'var(--bg-surface)'
                            },
                            children: editingItem === item.id ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    display: 'flex',
                                    flexDirection: 'column',
                                    gap: '8px'
                                },
                                children: [
                                    [
                                        'Hanzi',
                                        'Pinyin',
                                        'Translation'
                                    ].map((field)=>{
                                        const val = field === 'Hanzi' ? editHanzi : field === 'Pinyin' ? editPinyin : editTranslation;
                                        const setter = field === 'Hanzi' ? setEditHanzi : field === 'Pinyin' ? setEditPinyin : setEditTranslation;
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    style: {
                                                        fontSize: '10px',
                                                        color: 'var(--text-muted)',
                                                        textTransform: 'uppercase',
                                                        letterSpacing: '0.05em'
                                                    },
                                                    children: field
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                                    lineNumber: 161,
                                                    columnNumber: 25
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    value: val,
                                                    onChange: (e)=>setter(e.target.value),
                                                    style: {
                                                        display: 'block',
                                                        width: '100%',
                                                        marginTop: '4px',
                                                        padding: '8px 10px',
                                                        borderRadius: 'var(--radius-sm)',
                                                        border: '1px solid var(--border-focus)',
                                                        backgroundColor: 'var(--bg-app)',
                                                        fontSize: field === 'Hanzi' ? '20px' : '14px',
                                                        color: 'var(--text-primary)',
                                                        outline: 'none'
                                                    }
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                                    lineNumber: 162,
                                                    columnNumber: 25
                                                }, this)
                                            ]
                                        }, field, true, {
                                            fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                            lineNumber: 160,
                                            columnNumber: 23
                                        }, this);
                                    }),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: {
                                            display: 'flex',
                                            gap: '8px',
                                            marginTop: '4px'
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>saveItemEdit(reviewLesson, item.id),
                                                style: {
                                                    flex: 1,
                                                    padding: '8px',
                                                    borderRadius: 'var(--radius-sm)',
                                                    backgroundColor: 'var(--primary)',
                                                    color: '#fff',
                                                    fontSize: '12px',
                                                    fontWeight: 600
                                                },
                                                children: "Save"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                                lineNumber: 177,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>setEditingItem(null),
                                                style: {
                                                    padding: '8px 14px',
                                                    borderRadius: 'var(--radius-sm)',
                                                    border: '1px solid var(--border)',
                                                    fontSize: '12px'
                                                },
                                                children: "Cancel"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                                lineNumber: 183,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                        lineNumber: 176,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                lineNumber: 155,
                                columnNumber: 17
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '10px'
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: {
                                            flex: 1,
                                            minWidth: 0
                                        },
                                        children: [
                                            item.confidence === 'low' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                style: {
                                                    fontSize: '9px',
                                                    fontWeight: 700,
                                                    color: 'var(--accent)',
                                                    textTransform: 'uppercase',
                                                    letterSpacing: '0.05em',
                                                    display: 'block',
                                                    marginBottom: '4px'
                                                },
                                                children: "⚠ Review needed"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                                lineNumber: 195,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    display: 'flex',
                                                    alignItems: 'baseline',
                                                    gap: '8px',
                                                    flexWrap: 'wrap'
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        style: {
                                                            fontSize: '20px',
                                                            fontWeight: 700,
                                                            color: 'var(--text-primary)'
                                                        },
                                                        children: item.hanzi
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                                        lineNumber: 200,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        style: {
                                                            fontSize: '13px',
                                                            color: 'var(--text-secondary)',
                                                            fontStyle: 'italic'
                                                        },
                                                        children: item.pinyin || '—'
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                                        lineNumber: 201,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                                lineNumber: 199,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                style: {
                                                    fontSize: '12px',
                                                    color: 'var(--text-muted)',
                                                    marginTop: '3px',
                                                    overflow: 'hidden',
                                                    textOverflow: 'ellipsis',
                                                    whiteSpace: 'nowrap'
                                                },
                                                children: item.translation || '(no translation)'
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                                lineNumber: 203,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                        lineNumber: 193,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: {
                                            display: 'flex',
                                            gap: '4px',
                                            flexShrink: 0
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                "aria-label": "Pronounce",
                                                onClick: ()=>speakHanzi(item.hanzi),
                                                className: "tap-active",
                                                style: {
                                                    padding: '7px',
                                                    borderRadius: '50%',
                                                    backgroundColor: 'var(--bg-app)',
                                                    color: 'var(--text-secondary)'
                                                },
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$volume$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Volume2$3e$__["Volume2"], {
                                                    size: 14
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                                    lineNumber: 209,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                                lineNumber: 208,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                "aria-label": "Edit",
                                                onClick: ()=>{
                                                    setEditingItem(item.id);
                                                    setEditHanzi(item.hanzi);
                                                    setEditPinyin(item.pinyin);
                                                    setEditTranslation(item.translation);
                                                },
                                                className: "tap-active",
                                                style: {
                                                    padding: '7px',
                                                    borderRadius: '50%',
                                                    backgroundColor: 'var(--bg-app)',
                                                    color: 'var(--text-secondary)'
                                                },
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pencil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pencil$3e$__["Pencil"], {
                                                    size: 14
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                                    lineNumber: 217,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                                lineNumber: 211,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                "aria-label": "Approve",
                                                onClick: ()=>approvePendingItem(reviewLesson, item.id),
                                                className: "tap-active",
                                                style: {
                                                    padding: '7px',
                                                    borderRadius: '50%',
                                                    backgroundColor: 'var(--success-subtle)',
                                                    color: 'var(--success)'
                                                },
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                                    size: 14
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                                    lineNumber: 220,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                                lineNumber: 219,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                "aria-label": "Reject",
                                                onClick: ()=>rejectPendingItem(reviewLesson, item.id),
                                                className: "tap-active",
                                                style: {
                                                    padding: '7px',
                                                    borderRadius: '50%',
                                                    backgroundColor: 'var(--danger-subtle)',
                                                    color: 'var(--danger)'
                                                },
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                    size: 14
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                                    lineNumber: 223,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                                lineNumber: 222,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                        lineNumber: 207,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                lineNumber: 192,
                                columnNumber: 17
                            }, this)
                        }, item.id, false, {
                            fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                            lineNumber: 146,
                            columnNumber: 13
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                    lineNumber: 144,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/tabs/ReviewTab.tsx",
            lineNumber: 114,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "animate-fade-in",
        style: {
            padding: '16px 16px 80px 16px'
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                style: {
                    fontSize: '20px',
                    fontWeight: 700,
                    letterSpacing: '-0.02em',
                    marginBottom: '4px'
                },
                children: "Review Queue"
            }, void 0, false, {
                fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                lineNumber: 237,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                style: {
                    fontSize: '13px',
                    color: 'var(--text-secondary)',
                    marginBottom: '20px'
                },
                children: "AI-parsed words waiting for your approval before entering your study bank."
            }, void 0, false, {
                fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                lineNumber: 238,
                columnNumber: 7
            }, this),
            Object.keys(pendingStore).length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    padding: '40px 20px',
                    borderRadius: 'var(--radius-lg)',
                    border: '1px solid var(--border)',
                    textAlign: 'center',
                    backgroundColor: 'var(--bg-surface)'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clipboard$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ClipboardCheck$3e$__["ClipboardCheck"], {
                        size: 36,
                        style: {
                            color: 'var(--text-muted)',
                            margin: '0 auto 12px auto'
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                        lineNumber: 244,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        style: {
                            fontSize: '14px',
                            fontWeight: 500
                        },
                        children: "No words pending review."
                    }, void 0, false, {
                        fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                        lineNumber: 245,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        style: {
                            fontSize: '12px',
                            color: 'var(--text-muted)',
                            marginTop: '6px',
                            maxWidth: '260px',
                            margin: '6px auto 0 auto'
                        },
                        children: 'Tap "Sync Doc" to fetch and AI-parse your tutor\'s latest vocabulary.'
                    }, void 0, false, {
                        fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                        lineNumber: 246,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                lineNumber: 243,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '10px'
                },
                children: Object.entries(pendingStore).sort(([a], [b])=>new Date(b).getTime() - new Date(a).getTime()).map(([dateStr, lesson])=>{
                    const lowCount = lesson.items.filter((i)=>i.confidence === 'low').length;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        onClick: ()=>{
                            setReviewLesson(dateStr);
                            setEditingItem(null);
                        },
                        className: "tap-active",
                        style: {
                            padding: '16px',
                            borderRadius: 'var(--radius-lg)',
                            cursor: 'pointer',
                            border: `1px solid ${lowCount > 0 ? 'var(--accent)' : 'var(--border)'}`,
                            backgroundColor: 'var(--bg-surface)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        style: {
                                            fontSize: '15px',
                                            fontWeight: 600
                                        },
                                        children: new Date(dateStr).toLocaleDateString(undefined, {
                                            weekday: 'short',
                                            month: 'short',
                                            day: 'numeric',
                                            year: 'numeric'
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                        lineNumber: 269,
                                        columnNumber: 21
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: {
                                            display: 'flex',
                                            gap: '8px',
                                            marginTop: '4px'
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                style: {
                                                    fontSize: '11px',
                                                    color: 'var(--text-muted)'
                                                },
                                                children: [
                                                    lesson.items.length,
                                                    " words"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                                lineNumber: 273,
                                                columnNumber: 23
                                            }, this),
                                            lowCount > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                style: {
                                                    fontSize: '11px',
                                                    color: 'var(--accent)',
                                                    fontWeight: 600
                                                },
                                                children: [
                                                    "⚠ ",
                                                    lowCount,
                                                    " need attention"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                                lineNumber: 275,
                                                columnNumber: 25
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                        lineNumber: 272,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                lineNumber: 268,
                                columnNumber: 19
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                size: 16,
                                style: {
                                    color: 'var(--text-muted)'
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                                lineNumber: 279,
                                columnNumber: 19
                            }, this)
                        ]
                    }, dateStr, true, {
                        fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                        lineNumber: 257,
                        columnNumber: 17
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/src/components/tabs/ReviewTab.tsx",
                lineNumber: 251,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/tabs/ReviewTab.tsx",
        lineNumber: 236,
        columnNumber: 5
    }, this);
}
_s(ReviewTab, "tDob5KXW5z72TLo7hPIEv5/7aCA=");
_c = ReviewTab;
var _c;
__turbopack_context__.k.register(_c, "ReviewTab");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/book-open.mjs [app-client] (ecmascript) <export default as BookOpen>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Layers$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/layers.mjs [app-client] (ecmascript) <export default as Layers>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gamepad$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Gamepad2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/gamepad-2.mjs [app-client] (ecmascript) <export default as Gamepad2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$column$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart3$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chart-column.mjs [app-client] (ecmascript) <export default as BarChart3>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$refresh$2d$cw$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RefreshCw$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/refresh-cw.mjs [app-client] (ecmascript) <export default as RefreshCw>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-alert.mjs [app-client] (ecmascript) <export default as AlertCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.mjs [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clipboard$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ClipboardCheck$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/clipboard-check.mjs [app-client] (ecmascript) <export default as ClipboardCheck>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$pending$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/pending.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$tabs$2f$LessonsTab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/tabs/LessonsTab.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$tabs$2f$FlashcardsTab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/tabs/FlashcardsTab.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$tabs$2f$PracticeTab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/tabs/PracticeTab.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$tabs$2f$StatsTab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/tabs/StatsTab.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$tabs$2f$ReviewTab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/tabs/ReviewTab.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
// App shell — shared state, header, bottom nav, and tab routing
'use client';
;
;
;
;
;
;
;
;
function Home() {
    _s();
    const [activeTab, setActiveTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('lessons');
    const [pendingStore, setPendingStore] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [parsing, setParsing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [lessons, setLessons] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [vocabulary, setVocabulary] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [studyProgress, setStudyProgress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [syncStatus, setSyncStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [appMode, setAppMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('local');
    const [parseLog, setParseLog] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const abortRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            const storedLessons = localStorage.getItem('ch_lessons');
            const storedVocab = localStorage.getItem('ch_vocabulary');
            const storedProgress = localStorage.getItem('ch_progress');
            const storedMode = localStorage.getItem('ch_mode');
            if (storedLessons) setLessons(JSON.parse(storedLessons));
            if (storedVocab) setVocabulary(JSON.parse(storedVocab));
            if (storedProgress) setStudyProgress(JSON.parse(storedProgress));
            if (storedMode) setAppMode(storedMode);
            setPendingStore((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$pending$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadPending"])());
        }
    }["Home.useEffect"], []);
    const saveLocalData = (newLessons, newVocab, newProgress)=>{
        setLessons(newLessons);
        setVocabulary(newVocab);
        setStudyProgress(newProgress);
        localStorage.setItem('ch_lessons', JSON.stringify(newLessons));
        localStorage.setItem('ch_vocabulary', JSON.stringify(newVocab));
        localStorage.setItem('ch_progress', JSON.stringify(newProgress));
    };
    const speakHanzi = (hanzi)=>{
        if (("TURBOPACK compile-time value", "object") === 'undefined' || !window.speechSynthesis) return;
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(hanzi);
        utterance.lang = 'zh-CN';
        window.speechSynthesis.speak(utterance);
    };
    const handleSync = async ()=>{
        const controller = new AbortController();
        abortRef.current = controller;
        setParsing(true);
        setSyncStatus(null);
        setParseLog([]);
        try {
            const approvedDates = Array.from(new Set([
                ...lessons.map((l)=>l.date),
                ...vocabulary.map((v)=>v.lesson_id.replace(/^l_/, ''))
            ])).filter(Boolean);
            const pendingDates = Object.keys((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$pending$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadPending"])());
            const existingDates = Array.from(new Set([
                ...approvedDates,
                ...pendingDates
            ]));
            const res = await fetch('/api/parse', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    existingDates
                }),
                signal: controller.signal
            });
            if (!res.ok || !res.body) {
                const errData = await res.json().catch(()=>({}));
                setSyncStatus({
                    success: false,
                    message: errData.error || `Server error ${res.status}`
                });
                return;
            }
            const reader = res.body.getReader();
            const decoder = new TextDecoder();
            let buffer = '';
            let lessonsParsed = 0;
            let streamDone = false;
            while(!streamDone){
                const { done, value } = await reader.read();
                if (done) break;
                buffer += decoder.decode(value, {
                    stream: true
                });
                const lines = buffer.split('\n');
                buffer = lines.pop();
                for (const line of lines){
                    if (!line.startsWith('data: ')) continue;
                    let event;
                    try {
                        event = JSON.parse(line.slice(6));
                    } catch  {
                        continue;
                    }
                    if (event.type === 'parsing') {
                        setParseLog((prev)=>[
                                ...prev,
                                {
                                    date: event.date,
                                    status: 'parsing',
                                    words: 0
                                }
                            ]);
                    } else if (event.type === 'lesson') {
                        const words = event.items.length;
                        lessonsParsed++;
                        const current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$pending$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadPending"])();
                        current[event.date] = {
                            date: event.date,
                            rawLineCount: event.rawLineCount,
                            items: event.items
                        };
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$pending$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["savePending"])(current);
                        setPendingStore({
                            ...current
                        });
                        setParseLog((prev)=>prev.map((e)=>e.date === event.date ? {
                                    ...e,
                                    status: 'done',
                                    words
                                } : e));
                    } else if (event.type === 'done') {
                        if (lessonsParsed === 0) {
                            setSyncStatus({
                                success: true,
                                message: event.message || 'All lessons are already up to date!'
                            });
                        } else {
                            const current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$pending$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadPending"])();
                            setSyncStatus({
                                success: true,
                                message: `AI parsed ${lessonsParsed} new lessons → ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$pending$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["totalPendingCount"])(current)} words ready for review!`
                            });
                            setActiveTab('review');
                        }
                        streamDone = true;
                        break;
                    } else if (event.type === 'error') {
                        setSyncStatus({
                            success: false,
                            message: event.message
                        });
                        streamDone = true;
                        break;
                    }
                }
            }
        } catch (err) {
            if (err?.name !== 'AbortError') {
                setSyncStatus({
                    success: false,
                    message: 'Network error during AI parse.'
                });
            } else {
                const current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$pending$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadPending"])();
                const count = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$pending$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["totalPendingCount"])(current);
                setSyncStatus({
                    success: count > 0,
                    message: count > 0 ? `Stopped — ${count} words saved. Sync again to continue where you left off.` : 'Stopped before any lessons were saved.'
                });
            }
        } finally{
            setParsing(false);
            abortRef.current = null;
        }
    };
    const tabNavItems = [
        {
            id: 'lessons',
            label: 'Lessons',
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__["BookOpen"], {
                size: 18
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 166,
                columnNumber: 46
            }, this)
        },
        {
            id: 'flashcards',
            label: 'Flashcards',
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Layers$3e$__["Layers"], {
                size: 18
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 167,
                columnNumber: 52
            }, this)
        },
        {
            id: 'practice',
            label: 'Practice',
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gamepad$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Gamepad2$3e$__["Gamepad2"], {
                size: 18
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 168,
                columnNumber: 48
            }, this)
        },
        {
            id: 'review',
            label: 'Review',
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clipboard$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ClipboardCheck$3e$__["ClipboardCheck"], {
                size: 18
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 169,
                columnNumber: 44
            }, this),
            badge: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$pending$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["totalPendingCount"])(pendingStore)
        },
        {
            id: 'stats',
            label: 'Stats',
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$column$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart3$3e$__["BarChart3"], {
                size: 18
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 170,
                columnNumber: 42
            }, this)
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            maxWidth: '480px',
            margin: '0 auto',
            width: '100%',
            minHeight: '100vh',
            display: 'flex',
            flexDirection: 'column',
            backgroundColor: 'var(--bg-app)',
            position: 'relative'
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                style: {
                    padding: '18px 16px 12px 16px',
                    borderBottom: '1px solid var(--border)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    backgroundColor: 'var(--bg-surface)',
                    position: 'sticky',
                    top: 0,
                    zIndex: 50
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                style: {
                                    fontSize: '18px',
                                    fontWeight: 700,
                                    letterSpacing: '-0.02em',
                                    color: 'var(--text-primary)'
                                },
                                children: "Chinese Study Companion"
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 184,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                style: {
                                    fontSize: '11px',
                                    color: 'var(--text-muted)',
                                    display: 'block',
                                    marginTop: '2px'
                                },
                                children: appMode === 'local' ? 'Guest Mode (Browser Storage)' : 'Cloud Mode (Supabase)'
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 187,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 183,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: parsing ? ()=>abortRef.current?.abort() : handleSync,
                        className: "tap-active",
                        style: {
                            padding: '8px 12px',
                            borderRadius: 'var(--radius-sm)',
                            border: '1px solid var(--border)',
                            backgroundColor: parsing ? 'var(--danger-subtle)' : 'var(--bg-app)',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '6px',
                            fontSize: '12px',
                            fontWeight: 500,
                            color: parsing ? 'var(--danger)' : 'var(--text-primary)',
                            transition: 'all var(--transition-fast)'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$refresh$2d$cw$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RefreshCw$3e$__["RefreshCw"], {
                                size: 14,
                                style: {
                                    animation: parsing ? 'spin 1s linear infinite' : 'none'
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 203,
                                columnNumber: 11
                            }, this),
                            parsing ? 'Stop' : 'Sync Doc'
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 191,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 178,
                columnNumber: 7
            }, this),
            parsing && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    margin: '12px 16px 0 16px',
                    padding: '12px',
                    borderRadius: 'var(--radius-md)',
                    border: '1px solid var(--border)',
                    backgroundColor: 'var(--bg-surface)',
                    fontSize: '12px'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            fontWeight: 500,
                            color: 'var(--text-secondary)',
                            marginBottom: parseLog.length > 0 ? '8px' : 0
                        },
                        children: parseLog.length === 0 ? 'Fetching Google Doc…' : `Parsing lessons… (${parseLog.filter((e)=>e.status === 'done').length} / ${parseLog.length} done)`
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 213,
                        columnNumber: 11
                    }, this),
                    parseLog.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: 'flex',
                            flexDirection: 'column',
                            gap: '3px',
                            maxHeight: '140px',
                            overflowY: 'auto'
                        },
                        children: parseLog.map((entry)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '6px',
                                    fontFamily: 'monospace',
                                    fontSize: '11px'
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        style: {
                                            width: '12px',
                                            color: entry.status === 'done' ? 'var(--success)' : 'var(--text-muted)'
                                        },
                                        children: entry.status === 'done' ? '✓' : '…'
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/page.tsx",
                                        lineNumber: 222,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        style: {
                                            color: 'var(--text-primary)'
                                        },
                                        children: entry.date
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/page.tsx",
                                        lineNumber: 225,
                                        columnNumber: 19
                                    }, this),
                                    entry.status === 'done' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        style: {
                                            color: 'var(--text-muted)'
                                        },
                                        children: [
                                            "— ",
                                            entry.words,
                                            " words"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/page.tsx",
                                        lineNumber: 227,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, entry.date, true, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 221,
                                columnNumber: 17
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 219,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 209,
                columnNumber: 9
            }, this),
            syncStatus && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    margin: '12px 16px 0 16px',
                    padding: '12px',
                    borderRadius: 'var(--radius-md)',
                    backgroundColor: syncStatus.success ? 'var(--success-subtle)' : 'var(--danger-subtle)',
                    border: `1px solid ${syncStatus.success ? 'var(--success)' : 'var(--danger)'}`,
                    display: 'flex',
                    alignItems: 'start',
                    gap: '8px',
                    fontSize: '13px',
                    color: syncStatus.success ? 'var(--success)' : 'var(--danger)',
                    position: 'relative',
                    animation: 'fadeIn var(--transition-fast) forwards'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__["AlertCircle"], {
                        size: 16,
                        style: {
                            flexShrink: 0,
                            marginTop: '2px'
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 245,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            flex: 1,
                            paddingRight: '16px'
                        },
                        children: syncStatus.message
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 246,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setSyncStatus(null),
                        style: {
                            position: 'absolute',
                            right: '8px',
                            top: '8px',
                            opacity: 0.7
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                            size: 14
                        }, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 248,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 247,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 237,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                style: {
                    flex: 1,
                    padding: '16px 16px 80px 16px',
                    overflowY: 'auto'
                },
                children: [
                    activeTab === 'lessons' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$tabs$2f$LessonsTab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        lessons: lessons,
                        vocabulary: vocabulary,
                        speakHanzi: speakHanzi
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 255,
                        columnNumber: 11
                    }, this),
                    activeTab === 'flashcards' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$tabs$2f$FlashcardsTab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        vocabulary: vocabulary,
                        lessons: lessons,
                        studyProgress: studyProgress,
                        onSave: saveLocalData,
                        speakHanzi: speakHanzi
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 258,
                        columnNumber: 11
                    }, this),
                    activeTab === 'practice' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$tabs$2f$PracticeTab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        vocabulary: vocabulary,
                        lessons: lessons,
                        studyProgress: studyProgress,
                        onSave: saveLocalData,
                        speakHanzi: speakHanzi
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 264,
                        columnNumber: 11
                    }, this),
                    activeTab === 'stats' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$tabs$2f$StatsTab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        vocabulary: vocabulary,
                        studyProgress: studyProgress
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 270,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 253,
                columnNumber: 7
            }, this),
            activeTab === 'review' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$tabs$2f$ReviewTab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                pendingStore: pendingStore,
                onPendingUpdate: setPendingStore,
                lessons: lessons,
                vocabulary: vocabulary,
                studyProgress: studyProgress,
                onSave: saveLocalData,
                speakHanzi: speakHanzi
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 275,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                style: {
                    position: 'fixed',
                    bottom: 0,
                    left: 0,
                    right: 0,
                    maxWidth: '480px',
                    margin: '0 auto',
                    height: '60px',
                    backgroundColor: 'var(--bg-surface)',
                    borderTop: '1px solid var(--border)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-around',
                    paddingBottom: 'env(safe-area-inset-bottom)',
                    zIndex: 50
                },
                children: tabNavItems.map(({ id, label, icon, badge })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setActiveTab(id),
                        style: {
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            gap: '4px',
                            fontSize: '10px',
                            fontWeight: activeTab === id ? 600 : 500,
                            color: activeTab === id ? 'var(--primary)' : 'var(--text-secondary)',
                            transition: 'color var(--transition-fast)',
                            position: 'relative'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                style: {
                                    position: 'relative',
                                    display: 'inline-flex'
                                },
                                children: [
                                    icon,
                                    badge != null && badge > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        style: {
                                            position: 'absolute',
                                            top: '-5px',
                                            right: '-8px',
                                            backgroundColor: 'var(--accent)',
                                            color: '#fff',
                                            borderRadius: '99px',
                                            fontSize: '8px',
                                            fontWeight: 700,
                                            padding: '1px 4px',
                                            lineHeight: 1.4,
                                            minWidth: '14px',
                                            textAlign: 'center'
                                        },
                                        children: badge
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/page.tsx",
                                        lineNumber: 302,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 299,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: label
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 312,
                                columnNumber: 13
                            }, this)
                        ]
                    }, id, true, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 289,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 282,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/page.tsx",
        lineNumber: 174,
        columnNumber: 5
    }, this);
}
_s(Home, "ZM3N1A9G3P+HefjCXHH0GV8/LDE=");
_c = Home;
var _c;
__turbopack_context__.k.register(_c, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_0o1dj3f._.js.map