(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_0o1dj3f._.js","static/chunks/node_modules_0pskdsp._.js"],
    source: "dynamic"
});
